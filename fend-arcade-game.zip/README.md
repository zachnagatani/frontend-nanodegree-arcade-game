Arcade Game!

<!-- Getting Started -->

To load the game, simply open index.html (or go to http://zachnagatani.github.io/frontend-nanodegree-arcade-game/).

<!-- Gameplay -->

1. Use the arrow keys to navigate your character (the cat girl). Up will move you up, left will move you left, right will move you right, and down will move you... down!

2. Avoid the bugs (if you touch them, she gets grossed out and teleports all the back to the beginning).

3. Avoid the rocks, too. They may not have hands, but they can be pushy.

4. Stars are friendly, though. I mean, in real life, if you touched a star, you'd be dead before you even had a chance to. But this isn't real life. So touch those stars, and make (fake)life a little easier on yourself.

<!-- How to win -->
Get to the water and you win! (Sorta? You'll see)...
